package ba.sum.fsre.kvizznanja.ui.result

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import ba.sum.fsre.kvizznanja.AppDatabase
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class ResultViewModel(application: Application) : AndroidViewModel(application) {

    fun spremiRezultat(uid: String, score: Int) {
        val userRef = FirebaseFirestore.getInstance()
            .collection("korisnici")
            .document(uid)

        viewModelScope.launch {
            try {
                // 1. Ažuriraj Firestore transakcijom i dohvati nove vrijednosti
                val (noviUkupnoKvizova, noviBest, noviUkupniBodovi) =
                    FirebaseFirestore.getInstance().runTransaction { transaction ->
                        val snapshot      = transaction.get(userRef)
                        val trenutniBest  = snapshot.getLong("najbolji_rezultat") ?: 0
                        val ukupnoKvizova = (snapshot.getLong("ukupno_kvizova") ?: 0) + 1
                        val noviBest      = if (score > trenutniBest) score.toLong() else trenutniBest
                        val ukupniBodovi  = (snapshot.getLong("ukupni_bodovi") ?: 0) + score.toLong()

                        transaction.set(
                            userRef,
                            mapOf(
                                "ukupno_kvizova"    to ukupnoKvizova,
                                "najbolji_rezultat" to noviBest,
                                "ukupni_bodovi"     to ukupniBodovi
                            ),
                            SetOptions.merge()
                        )

                        Triple(ukupnoKvizova, noviBest, ukupniBodovi)
                    }.await()

                // 2. Odmah ažuriraj Room — cache ostaje konzistentan s Firestore-om
                val dao = AppDatabase.getInstance(getApplication()).userProfileDao()
                val lokalniProfil = dao.findByUid(uid)
                if (lokalniProfil != null) {
                    dao.insertOrReplace(
                        lokalniProfil.copy(
                            ukupnoKvizova    = noviUkupnoKvizova.toInt(),
                            najboljiRezultat = noviBest.toInt(),
                            ukupniBodovi     = noviUkupniBodovi.toInt(),
                            lastLoginAt      = System.currentTimeMillis()
                        )
                    )
                }
            } catch (_: Exception) {
                // Nema interneta — podaci će se sinkronizirati
                // kad korisnik sljedeći put otvori profil
            }
        }
    }
}

