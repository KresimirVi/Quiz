package ba.sum.fsre.kvizznanja.ui.auth

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import ba.sum.fsre.kvizznanja.R
import ba.sum.fsre.kvizznanja.SessionManager
import ba.sum.fsre.kvizznanja.ui.home.HomeActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.launch

class LoginActivity : AppCompatActivity() {

    private lateinit var editEmail: TextInputEditText
    private lateinit var editPassword: TextInputEditText
    private lateinit var btnLogin: MaterialButton
    private lateinit var btnGoRegister: MaterialButton
    private lateinit var tvForgot: TextView

    private val viewModel: LoginViewModel by viewModels()
    private lateinit var session: SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_login)
        supportActionBar?.hide()

        session = SessionManager(context = this)

        if (viewModel.currentUser() != null && session.isLoggedIn()) {
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
            return
        }

        editEmail     = findViewById(R.id.etEmail)
        editPassword  = findViewById(R.id.etPassword)
        btnLogin      = findViewById(R.id.btnLogin)
        btnGoRegister = findViewById(R.id.btnRegister)
        tvForgot      = findViewById(R.id.tvForgot)

        // Promatraj stanje prijave iz ViewModela
        lifecycleScope.launch {
            viewModel.loginState.collect { state ->
                when (state) {
                    is LoginState.Loading -> btnLogin.isEnabled = false
                    is LoginState.Success -> {
                        session.saveLoginWithUid(state.user.uid)
                        startActivity(Intent(this@LoginActivity, HomeActivity::class.java))
                        finish()
                    }
                    is LoginState.Error -> {
                        btnLogin.isEnabled = true
                        Toast.makeText(this@LoginActivity, state.message, Toast.LENGTH_SHORT).show()
                    }
                    is LoginState.Idle -> Unit
                }
            }
        }

        btnLogin.setOnClickListener {
            val email    = editEmail.text.toString().trim()
            val password = editPassword.text.toString()

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Unesite email i lozinku", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            viewModel.login(email, password)
        }

        btnGoRegister.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }

        tvForgot.setOnClickListener {
            startActivity(Intent(this, ResetPasswordActivity::class.java))
        }
    }
}