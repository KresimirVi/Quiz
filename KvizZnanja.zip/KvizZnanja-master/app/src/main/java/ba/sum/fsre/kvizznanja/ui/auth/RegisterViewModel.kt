package ba.sum.fsre.kvizznanja.ui.auth

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import ba.sum.fsre.kvizznanja.AppDatabase
import ba.sum.fsre.kvizznanja.AuthRepository
import ba.sum.fsre.kvizznanja.UserProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class RegisterViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = AuthRepository()

    private val _registerState = MutableStateFlow<RegisterState>(RegisterState.Idle)
    val registerState: StateFlow<RegisterState> = _registerState

    fun register(fullName: String, email: String, password: String) {
        _registerState.value = RegisterState.Loading
        viewModelScope.launch {
            val result = repo.register(fullName, email, password)
            result.onSuccess { userId ->
                val uid = repo.currentUser()?.uid
                if (uid != null) {
                    try {
                        AppDatabase.getInstance(getApplication()).userProfileDao()
                            .insertOrReplace(
                                UserProfile(
                                    uid      = uid,
                                    fullName = fullName,
                                    email    = email
                                )
                            )
                    } catch (_: Exception) { /* nije kritično */ }
                    _registerState.value = RegisterState.Success(uid)
                } else {
                    _registerState.value = RegisterState.Success(userId.toString())
                }
            }.onFailure { e ->
                _registerState.value = RegisterState.Error(e.message ?: "Greška pri registraciji")
            }
        }
    }

    fun currentUser() = repo.currentUser()
    fun logout()      = repo.logout()
}

sealed class RegisterState {
    object Idle    : RegisterState()
    object Loading : RegisterState()
    data class Success(val uid: String)   : RegisterState()
    data class Error(val message: String) : RegisterState()
}

