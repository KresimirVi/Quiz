package ba.sum.fsre.kvizznanja.model

data class Odgovor (
    val id: String,
    val tekstOdgovora: String,
    val jeTocan: Boolean
)
