package ba.sum.fsre.kvizznanja.ui.auth

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.viewModels
import androidx.lifecycle.lifecycleScope
import android.widget.Toast
import ba.sum.fsre.kvizznanja.R
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class ResetPasswordActivity : AppCompatActivity() {

    private val viewModel: ResetPasswordViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reset_password)
        supportActionBar?.hide()

        val tilEmail         = findViewById<TextInputLayout>(R.id.tilEmail)
        val etEmail          = findViewById<TextInputEditText>(R.id.etEmail)
        val btnSendResetLink = findViewById<MaterialButton>(R.id.btnSendResetLink)
        val btnBackToLogin   = findViewById<MaterialButton>(R.id.btnBackToLogin)

        btnBackToLogin.setOnClickListener { finish() }

        // Promatraj stanje reset-a iz ViewModela
        lifecycleScope.launch {
            viewModel.resetState.collect { state ->
                when (state) {
                    is ResetState.Loading -> {
                        btnSendResetLink.isEnabled = false
                        btnSendResetLink.text = "Slanje..."
                    }
                    is ResetState.Success -> {
                        Toast.makeText(
                            this@ResetPasswordActivity,
                            "✓ Link za resetiranje poslan na ${etEmail.text.toString().trim()}",
                            Toast.LENGTH_LONG
                        ).show()
                        delay(1500)
                        startActivity(Intent(this@ResetPasswordActivity, LoginActivity::class.java).apply {
                            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                        })
                        finish()
                    }
                    is ResetState.Error -> {
                        btnSendResetLink.isEnabled = true
                        btnSendResetLink.text = "Pošalji link"
                        tilEmail.error = state.message
                    }
                    is ResetState.Idle -> Unit
                }
            }
        }

        btnSendResetLink.setOnClickListener {
            val email = etEmail.text.toString().trim()

            if (email.isEmpty()) {
                tilEmail.error = "Unesite email adresu"
                return@setOnClickListener
            }
            if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                tilEmail.error = "Nevažeći format emaila"
                return@setOnClickListener
            }

            tilEmail.error = null
            viewModel.sendResetEmail(email)
        }
    }
}