package ba.sum.fsre.kvizznanja.ui.profile

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import ba.sum.fsre.kvizznanja.AppDatabase
import ba.sum.fsre.kvizznanja.AuthRepository
import ba.sum.fsre.kvizznanja.UserProfile
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class ProfileViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = AuthRepository()
    private val dao  = AppDatabase.getInstance(application).userProfileDao()

    private val _profileState = MutableStateFlow<ProfileState>(ProfileState.Loading)
    val profileState: StateFlow<ProfileState> = _profileState

    fun loadProfile(uid: String) {
        viewModelScope.launch {
            // 1. Prvo čitaj iz Room (brzo, radi offline)
            val lokalniProfil = dao.findByUid(uid)
            if (lokalniProfil != null) {
                _profileState.value = ProfileState.Success(lokalniProfil)
            }

            // 2. Osvježi iz Firestorea u pozadini i ažuriraj Room
            try {
                val doc = FirebaseFirestore.getInstance()
                    .collection("korisnici")
                    .document(uid)
                    .get()
                    .await()

                val azurirani = UserProfile(
                    uid              = uid,
                    fullName         = doc.getString("ime") ?: lokalniProfil?.fullName ?: "—",
                    email            = doc.getString("email") ?: lokalniProfil?.email ?: "—",
                    ukupnoKvizova    = (doc.getLong("ukupno_kvizova") ?: 0).toInt(),
                    najboljiRezultat = (doc.getLong("najbolji_rezultat") ?: 0).toInt(),
                    ukupniBodovi     = (doc.getLong("ukupni_bodovi") ?: 0).toInt(),
                    createdAt        = lokalniProfil?.createdAt ?: System.currentTimeMillis(),
                    lastLoginAt      = System.currentTimeMillis()
                )
                dao.insertOrReplace(azurirani)
                _profileState.value = ProfileState.Success(azurirani)
            } catch (_: Exception) {
                // Nema interneta — Room podaci ostaju na ekranu
                if (lokalniProfil == null) {
                    _profileState.value = ProfileState.Error("Nema podataka")
                }
            }
        }
    }

    fun logout(uid: String) {
        viewModelScope.launch {
            try { dao.deleteByUid(uid) } catch (_: Exception) { }
            repo.logout()
        }
    }

    fun currentUser() = repo.currentUser()
}

sealed class ProfileState {
    object Loading : ProfileState()
    data class Success(val profile: UserProfile) : ProfileState()
    data class Error(val message: String)        : ProfileState()
}

