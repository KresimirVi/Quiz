package ba.sum.fsre.kvizznanja

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

class AuthRepository {

    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()

    suspend fun register(fullName: String, email: String, password: String): Result<Long> {
        val name = fullName.trim()
        val mail = email.trim().lowercase()

        if (name.isBlank()) return Result.failure(IllegalArgumentException("Ime je obavezno"))
        if (mail.isBlank()) return Result.failure(IllegalArgumentException("Email je obavezan"))
        if (password.length < 6) return Result.failure(IllegalArgumentException("Lozinka mora imati min. 6 znakova"))

        return try {
            val result = auth.createUserWithEmailAndPassword(mail, password).await()
            val user = result.user ?: return Result.failure(Exception("Greška pri registraciji"))

            val korisnikData = hashMapOf(
                "ime" to name,
                "email" to mail,
                "uid" to user.uid,
                "createdAt" to System.currentTimeMillis(),
                "ukupni_bodovi" to 0,
                "ukupno_kvizova" to 0,
                "najbolji_rezultat" to 0
            )
            firestore.collection("korisnici").document(user.uid).set(korisnikData).await()

            Result.success(user.uid.hashCode().toLong())
        } catch (e: Exception) {
            val msg = when {
                e.message?.contains("email address is already in use") == true -> "Email je već registriran"
                e.message?.contains("badly formatted") == true -> "Nevažeći format emaila"
                else -> e.message ?: "Greška pri registraciji"
            }
            Result.failure(Exception(msg))
        }
    }

    suspend fun login(email: String, password: String): Result<FirebaseUserData> {
        val mail = email.trim().lowercase()
        if (mail.isBlank()) return Result.failure(IllegalArgumentException("Email je obavezan"))
        if (password.isBlank()) return Result.failure(IllegalArgumentException("Lozinka je obavezna"))

        return try {
            val result = auth.signInWithEmailAndPassword(mail, password).await()
            val user = result.user ?: return Result.failure(Exception("Greška pri prijavi"))

            val doc = firestore.collection("korisnici").document(user.uid).get().await()
            val ime = doc.getString("ime") ?: "Korisnik"

            Result.success(FirebaseUserData(uid = user.uid, fullName = ime))
        } catch (e: Exception) {
            val msg = when {
                e.message?.contains("no user record") == true -> "Korisnik ne postoji"
                e.message?.contains("INVALID_LOGIN_CREDENTIALS") == true -> "Pogrešan email ili lozinka"
                e.message?.contains("badly formatted") == true -> "Nevažeći format emaila"
                else -> e.message ?: "Greška pri prijavi"
            }
            Result.failure(Exception(msg))
        }
    }

    suspend fun sendPasswordResetEmail(email: String): Result<Unit> {
        val mail = email.trim().lowercase()
        if (mail.isBlank()) return Result.failure(IllegalArgumentException("Unesite email adresu"))

        return try {
            auth.sendPasswordResetEmail(mail).await()
            Result.success(Unit)
        } catch (e: Exception) {
            val msg = when {
                e.message?.contains("no user record") == true -> "Email nije pronađen u sustavu"
                e.message?.contains("badly formatted") == true -> "Nevažeći format emaila"
                else -> "Greška pri slanju. Provjerite adresu."
            }
            Result.failure(Exception(msg))
        }
    }

    fun currentUser(): FirebaseUser? = auth.currentUser
    fun logout() = auth.signOut()
}

data class FirebaseUserData(
    val uid: String,
    val fullName: String
) {
    val id: Long get() = uid.hashCode().toLong()
}