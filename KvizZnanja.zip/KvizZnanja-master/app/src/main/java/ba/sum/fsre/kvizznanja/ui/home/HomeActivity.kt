package ba.sum.fsre.kvizznanja.ui.home

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import ba.sum.fsre.kvizznanja.R
import ba.sum.fsre.kvizznanja.SessionManager
import ba.sum.fsre.kvizznanja.ui.auth.LoginActivity
import ba.sum.fsre.kvizznanja.ui.leaderboard.LeaderboardActivity
import ba.sum.fsre.kvizznanja.ui.profile.ProfileActivity
import ba.sum.fsre.kvizznanja.ui.quiz.QuizActivity
import com.google.android.material.button.MaterialButton

class HomeActivity : AppCompatActivity() {

    private lateinit var session: SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        session = SessionManager(this)

        if (!session.isLoggedIn()) {
            goToLogin(clearBackStack = true)
            return
        }

        enableEdgeToEdge()
        setContentView(R.layout.activity_home)
        supportActionBar?.hide()

        // Kategorije
        findViewById<MaterialButton>(R.id.btnKategorija1).setOnClickListener { startQuiz(1) }
        findViewById<MaterialButton>(R.id.btnKategorija2).setOnClickListener { startQuiz(2) }
        findViewById<MaterialButton>(R.id.btnKategorija3).setOnClickListener { startQuiz(3) }
        findViewById<MaterialButton>(R.id.btnKategorija4).setOnClickListener { startQuiz(4) }

        // Profil - ImageButton
        findViewById<ImageButton>(R.id.btnProfile).setOnClickListener {
            startActivity(Intent(this, ProfileActivity::class.java))
        }

        // Ljestvica
        findViewById<MaterialButton>(R.id.btnLeaderboard).setOnClickListener {
            startActivity(Intent(this, LeaderboardActivity::class.java))
        }


    }

    private fun startQuiz(category: Int) {
        val kategorijaId = when (category) {
            1 -> "opce_znanje"
            2 -> "povijest"
            3 -> "film_i_glazba"
            4 -> "sport"
            else -> "opce_znanje"
        }
        val intent = Intent(this, QuizActivity::class.java)
        intent.putExtra("kategorija_id", kategorijaId)
        startActivity(intent)
    }

    private fun goToLogin(clearBackStack: Boolean) {
        val intent = Intent(this, LoginActivity::class.java)
        if (clearBackStack) {
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        startActivity(intent)
        finish()
    }
}