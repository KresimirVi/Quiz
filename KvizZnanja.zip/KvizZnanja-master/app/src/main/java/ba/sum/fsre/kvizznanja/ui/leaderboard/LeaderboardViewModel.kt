package ba.sum.fsre.kvizznanja.ui.leaderboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class LeaderboardViewModel : ViewModel() {

    private val _entries = MutableStateFlow<List<LeaderboardEntry>>(emptyList())
    val entries: StateFlow<List<LeaderboardEntry>> = _entries

    init {
        loadLeaderboard()
    }

    private fun loadLeaderboard() {
        viewModelScope.launch {
            try {
                val docs = FirebaseFirestore.getInstance()
                    .collection("korisnici")
                    .orderBy("ukupni_bodovi", Query.Direction.DESCENDING)
                    .limit(10)
                    .get()
                    .await()

                _entries.value = docs.mapIndexed { index, doc ->
                    LeaderboardEntry(
                        rank  = index + 1,
                        name  = doc.getString("ime") ?: "Korisnik ${index + 1}",
                        score = (doc.getLong("ukupni_bodovi") ?: 0).toInt()
                    )
                }
            } catch (_: Exception) { /* nema interneta */ }
        }
    }
}

