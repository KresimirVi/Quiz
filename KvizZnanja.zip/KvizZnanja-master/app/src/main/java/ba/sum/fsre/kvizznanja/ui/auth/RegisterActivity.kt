package ba.sum.fsre.kvizznanja.ui.auth

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import ba.sum.fsre.kvizznanja.R
import ba.sum.fsre.kvizznanja.SessionManager
import ba.sum.fsre.kvizznanja.ui.home.HomeActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.launch

class RegisterActivity : AppCompatActivity() {

    private lateinit var editFullName: TextInputEditText
    private lateinit var editEmail: TextInputEditText
    private lateinit var editPassword: TextInputEditText
    private lateinit var editPassword2: TextInputEditText
    private lateinit var btnRegister: MaterialButton
    private lateinit var btnBackToLogin: MaterialButton

    private val viewModel: RegisterViewModel by viewModels()
    private lateinit var session: SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        session = SessionManager(this)

        if (session.isLoggedIn() && viewModel.currentUser() != null) {
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
            return
        }
        viewModel.logout()

        setContentView(R.layout.activity_register)
        supportActionBar?.hide()

        editFullName   = findViewById(R.id.etFullName)
        editEmail      = findViewById(R.id.etEmail)
        editPassword   = findViewById(R.id.etPassword)
        editPassword2  = findViewById(R.id.etRepeatPassword)
        btnRegister    = findViewById(R.id.btnRegister)
        btnBackToLogin = findViewById(R.id.btnBackToLogin)

        // Promatraj stanje registracije iz ViewModela
        lifecycleScope.launch {
            viewModel.registerState.collect { state ->
                when (state) {
                    is RegisterState.Loading -> btnRegister.isEnabled = false
                    is RegisterState.Success -> {
                        session.saveLoginWithUid(state.uid)
                        startActivity(Intent(this@RegisterActivity, HomeActivity::class.java))
                        finish()
                    }
                    is RegisterState.Error -> {
                        btnRegister.isEnabled = true
                        Toast.makeText(this@RegisterActivity, state.message, Toast.LENGTH_SHORT).show()
                    }
                    is RegisterState.Idle -> Unit
                }
            }
        }

        btnRegister.setOnClickListener {
            val fullName  = editFullName.text.toString().trim()
            val email     = editEmail.text.toString().trim()
            val password1 = editPassword.text.toString()
            val password2 = editPassword2.text.toString()

            if (password1 != password2) {
                Toast.makeText(this, "Lozinke se ne podudaraju", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            viewModel.register(fullName, email, password1)
        }

        btnBackToLogin.setOnClickListener { finish() }
    }
}