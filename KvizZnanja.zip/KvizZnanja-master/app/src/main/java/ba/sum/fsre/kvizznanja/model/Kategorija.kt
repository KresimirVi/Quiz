package ba.sum.fsre.kvizznanja.model

data class Kategorija (
    val id: String,
    val naziv: String,
    val opis: String = ""
)
