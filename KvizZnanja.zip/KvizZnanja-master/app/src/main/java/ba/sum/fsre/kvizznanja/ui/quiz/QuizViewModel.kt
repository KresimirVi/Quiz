package ba.sum.fsre.kvizznanja.ui.quiz

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class QuizViewModel : ViewModel() {

    private val db = FirebaseFirestore.getInstance()

    private val _quizState = MutableStateFlow<QuizState>(QuizState.Loading)
    val quizState: StateFlow<QuizState> = _quizState

    private val _answerState = MutableStateFlow<AnswerState>(AnswerState.Idle)
    val answerState: StateFlow<AnswerState> = _answerState

    private val questions = mutableListOf<Question>()
    var currentIndex = 0
        private set
    var score = 0
        private set
    private var answered = false

    fun loadQuestions(kategorijaId: String) {
        if (questions.isNotEmpty()) {
            _quizState.value = QuizState.QuestionReady(
                question       = questions[currentIndex],
                questionIndex  = currentIndex,
                totalQuestions = questions.size
            )
            return
        }

        _quizState.value = QuizState.Loading

        viewModelScope.launch {
            try {
                val pitanjaDocs = db.collection("pitanja")
                    .whereEqualTo("kategorija_id", kategorijaId)
                    .get()
                    .await()

                if (pitanjaDocs.isEmpty) {
                    _quizState.value = QuizState.Error("Nema pitanja za ovu kategoriju.")
                    return@launch
                }

                // Svi upiti idu PARALELNO - ovo je fix za sporo učitavanje
                val tempQuestions = pitanjaDocs.map { pitanjeDoc ->
                    async {
                        val tekstPitanja = pitanjeDoc.getString("tekst_pitanja")
                            ?: return@async null

                        val odgovoriDocs = pitanjeDoc.reference.collection("odgovori").get().await()
                        val odgovori     = mutableListOf<String>()
                        var tocniIndex   = 0

                        val sortiraniOdgovori = odgovoriDocs.sortedBy { it.id }
                        sortiraniOdgovori.forEachIndexed { index, odgovorDoc ->
                            val tekst   = odgovorDoc.getString("tekst_odgovora") ?: ""
                            val jeTacan = odgovorDoc.getBoolean("je_tocan") ?: false
                            odgovori.add(tekst)
                            if (jeTacan) tocniIndex = index
                        }

                        if (odgovori.size == 4) {
                            val shuffled       = odgovori.mapIndexed { i, a -> Pair(a, i == tocniIndex) }.shuffled()
                            val noviTocniIndex = shuffled.indexOfFirst { it.second }
                            Question(
                                text         = tekstPitanja,
                                answers      = shuffled.map { it.first },
                                correctIndex = noviTocniIndex
                            )
                        } else null
                    }
                }.awaitAll().filterNotNull()

                val finalQuestions = tempQuestions.shuffled().take(10)
                questions.addAll(finalQuestions)
                currentIndex = 0

                _quizState.value = QuizState.QuestionReady(
                    question       = questions[currentIndex],
                    questionIndex  = currentIndex,
                    totalQuestions = questions.size
                )

            } catch (_: Exception) {
                _quizState.value = QuizState.Error("Greška pri učitavanju pitanja.")
            }
        }
    }

    fun onAnswerSelected(selectedIndex: Int) {
        if (answered) return
        answered = true

        val correct = questions[currentIndex].correctIndex
        if (selectedIndex == correct) score++

        _answerState.value = AnswerState.Answered(
            selectedIndex = selectedIndex,
            correctIndex  = correct
        )
    }

    fun nextQuestion() {
        currentIndex++
        answered = false
        _answerState.value = AnswerState.Idle

        if (currentIndex < questions.size) {
            _quizState.value = QuizState.QuestionReady(
                question       = questions[currentIndex],
                questionIndex  = currentIndex,
                totalQuestions = questions.size
            )
        } else {
            _quizState.value = QuizState.Finished(
                score = score,
                total = questions.size
            )
        }
    }
}

sealed class QuizState {
    object Loading : QuizState()
    data class QuestionReady(
        val question: Question,
        val questionIndex: Int,
        val totalQuestions: Int
    ) : QuizState()
    data class Finished(val score: Int, val total: Int) : QuizState()
    data class Error(val message: String) : QuizState()
}

sealed class AnswerState {
    object Idle : AnswerState()
    data class Answered(val selectedIndex: Int, val correctIndex: Int) : AnswerState()
}