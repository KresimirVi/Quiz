package ba.sum.fsre.kvizznanja.model

data class Rezultat(
    val id: String,
    val userId: String,
    val kategorijaId: String,
    val brojTocnih: Int,
    val ukupanBrojPitanja: Int,
    val bodovi: Int,
    val createdAt: Long = System.currentTimeMillis()
)
