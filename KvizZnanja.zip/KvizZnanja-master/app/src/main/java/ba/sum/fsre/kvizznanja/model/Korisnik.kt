package ba.sum.fsre.kvizznanja.model

data class Korisnik(
    val korisnikId: String,
    val naziv: String,
    val email: String,
    val lozinkaHash: String,
    val datumRegistracije: Long = System.currentTimeMillis()
)