package ba.sum.fsre.kvizznanja.model

data class Pitanje (
    val id: String,
    val tekstPitanja: String,
    val kategorijaId: String,
    val odgovori: List<Odgovor> = emptyList()
)
