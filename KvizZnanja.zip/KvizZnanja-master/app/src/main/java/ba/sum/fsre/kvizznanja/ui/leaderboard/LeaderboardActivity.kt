package ba.sum.fsre.kvizznanja.ui.leaderboard

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import ba.sum.fsre.kvizznanja.R
import ba.sum.fsre.kvizznanja.ui.home.HomeActivity
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.launch

data class LeaderboardEntry(
    val rank: Int,
    val name: String,
    val score: Int
)

class LeaderboardActivity : AppCompatActivity() {

    private val viewModel: LeaderboardViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_leaderboard)

        supportActionBar?.hide()

        val rvLeaderboard = findViewById<RecyclerView>(R.id.rvLeaderboard)

        // Promatraj listu iz ViewModela
        lifecycleScope.launch {
            viewModel.entries.collect { entries ->
                rvLeaderboard.layoutManager = LinearLayoutManager(this@LeaderboardActivity)
                rvLeaderboard.adapter = LeaderboardAdapter(entries)
            }
        }

        findViewById<MaterialButton>(R.id.btnBackToHome).setOnClickListener {
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
        }
    }
}

class LeaderboardAdapter(private val entries: List<LeaderboardEntry>) :
    RecyclerView.Adapter<LeaderboardAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvRank: TextView = view.findViewById(R.id.tvRank)
        val tvName: TextView = view.findViewById(R.id.tvName)
        val tvScore: TextView = view.findViewById(R.id.tvScore)
        val tvTrophy: TextView = view.findViewById(R.id.tvTrophy)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_leaderboard, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val entry = entries[position]
        holder.tvName.text = entry.name
        holder.tvScore.text = "${entry.score} pts"

        when (entry.rank) {
            1 -> { holder.tvTrophy.text = "🏆"; holder.tvRank.text = "" }
            2 -> { holder.tvTrophy.text = "🥈"; holder.tvRank.text = "" }
            3 -> { holder.tvTrophy.text = "🥉"; holder.tvRank.text = "" }
            else -> { holder.tvTrophy.text = ""; holder.tvRank.text = "${entry.rank}" }
        }
    }

    override fun getItemCount() = entries.size
}