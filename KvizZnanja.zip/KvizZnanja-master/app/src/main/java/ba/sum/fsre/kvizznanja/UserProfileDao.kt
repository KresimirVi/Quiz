package ba.sum.fsre.kvizznanja

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface UserProfileDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrReplace(profile: UserProfile)

    @Query("SELECT * FROM user_profile WHERE uid = :uid LIMIT 1")
    suspend fun findByUid(uid: String): UserProfile?

    @Query("SELECT * FROM user_profile WHERE email = :email LIMIT 1")
    suspend fun findByEmail(email: String): UserProfile?

    @Query("""
        UPDATE user_profile 
        SET ukupnoKvizova = :ukupnoKvizova, 
            najboljiRezultat = :najboljiRezultat,
            ukupniBodovi = :ukupniBodovi
        WHERE uid = :uid
    """)
    suspend fun updateStats(uid: String, ukupnoKvizova: Int, najboljiRezultat: Int, ukupniBodovi: Int)

    @Query("UPDATE user_profile SET lastLoginAt = :ts WHERE uid = :uid")
    suspend fun updateLastLogin(uid: String, ts: Long = System.currentTimeMillis())

    @Query("DELETE FROM user_profile WHERE uid = :uid")
    suspend fun deleteByUid(uid: String)

    @Query("SELECT * FROM user_profile ORDER BY createdAt DESC")
    suspend fun getAllProfiles(): List<UserProfile>
}