package ba.sum.fsre.kvizznanja.ui.quiz

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import ba.sum.fsre.kvizznanja.R
import ba.sum.fsre.kvizznanja.ui.result.ResultActivity
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.launch

data class Question(
    val text: String,
    val answers: List<String>,
    val correctIndex: Int
)

class QuizActivity : AppCompatActivity() {

    private lateinit var tvQuestionNumber: TextView
    private lateinit var tvQuestion: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var btnNext: MaterialButton
    private lateinit var answerButtons: List<MaterialButton>

    private val viewModel: QuizViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quiz)
        supportActionBar?.hide()

        tvQuestionNumber = findViewById(R.id.tvQuestionNumber)
        tvQuestion       = findViewById(R.id.tvQuestion)
        progressBar      = findViewById(R.id.progressBar)
        btnNext          = findViewById(R.id.btnNext)

        answerButtons = listOf(
            findViewById(R.id.btnAnswer1),
            findViewById(R.id.btnAnswer2),
            findViewById(R.id.btnAnswer3),
            findViewById(R.id.btnAnswer4)
        )

        // Odabir odgovora → ViewModel
        answerButtons.forEachIndexed { index, button ->
            button.setOnClickListener { viewModel.onAnswerSelected(index) }
        }

        // Sljedeće pitanje → ViewModel
        btnNext.setOnClickListener { viewModel.nextQuestion() }

        // Promatraj stanje kviza
        lifecycleScope.launch {
            viewModel.quizState.collect { state ->
                when (state) {
                    is QuizState.Loading -> {
                        tvQuestion.text = "Učitavam pitanja..."
                        answerButtons.forEach { it.isEnabled = false }
                    }
                    is QuizState.QuestionReady -> prikaziPitanje(state)
                    is QuizState.Finished -> {
                        val intent = Intent(this@QuizActivity, ResultActivity::class.java)
                        intent.putExtra("CORRECT", state.score)
                        intent.putExtra("TOTAL", state.total)
                        intent.putExtra("SCORE", state.score)
                        startActivity(intent)
                        finish()
                    }
                    is QuizState.Error -> {
                        tvQuestion.text = state.message
                        answerButtons.forEach { it.isEnabled = false }
                    }
                }
            }
        }

        // Promatraj stanje odgovora (bojanje gumba)
        lifecycleScope.launch {
            viewModel.answerState.collect { state ->
                when (state) {
                    is AnswerState.Idle -> Unit
                    is AnswerState.Answered -> obojiOdgovore(state.selectedIndex, state.correctIndex)
                }
            }
        }

        val kategorijaId = intent.getStringExtra("kategorija_id") ?: "opce_znanje"
        viewModel.loadQuestions(kategorijaId)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    private fun prikaziPitanje(state: QuizState.QuestionReady) {
        val q = state.question

        tvQuestionNumber.text = "PITANJE ${state.questionIndex + 1} / ${state.totalQuestions}"
        progressBar.progress  = ((state.questionIndex + 1) * 100 / state.totalQuestions)
        tvQuestion.text       = q.text
        btnNext.visibility    = View.GONE

        answerButtons.forEachIndexed { index, button ->
            button.text = q.answers[index]
            button.isEnabled = true
            button.backgroundTintList = android.content.res.ColorStateList.valueOf(android.graphics.Color.WHITE)
            button.setTextColor(android.graphics.Color.parseColor("#1E1E1E"))
            button.strokeColor = android.content.res.ColorStateList.valueOf(android.graphics.Color.parseColor("#CCCCCC"))
        }
    }

    private fun obojiOdgovore(selectedIndex: Int, correctIndex: Int) {
        answerButtons.forEachIndexed { index, button ->
            button.isEnabled = false
            when {
                index == correctIndex -> {
                    button.backgroundTintList = android.content.res.ColorStateList.valueOf(android.graphics.Color.parseColor("#1B5E20"))
                    button.setTextColor(android.graphics.Color.parseColor("#4CAF50"))
                    button.strokeColor = android.content.res.ColorStateList.valueOf(android.graphics.Color.parseColor("#4CAF50"))
                }
                index == selectedIndex -> {
                    button.backgroundTintList = android.content.res.ColorStateList.valueOf(android.graphics.Color.parseColor("#B71C1C"))
                    button.setTextColor(android.graphics.Color.parseColor("#F44336"))
                    button.strokeColor = android.content.res.ColorStateList.valueOf(android.graphics.Color.parseColor("#F44336"))
                }
            }
        }

        btnNext.visibility = View.VISIBLE
    }
}