package ba.sum.fsre.kvizznanja.model

data class QuizSession(
    val userId: String,
    val kategorijaId: String,
    val pitanja: List<Pitanje>,
    var currentIndex: Int = 0,
    var tocni: Int = 0
)
