package ba.sum.fsre.kvizznanja.ui.auth

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import ba.sum.fsre.kvizznanja.AppDatabase
import ba.sum.fsre.kvizznanja.AuthRepository
import ba.sum.fsre.kvizznanja.FirebaseUserData
import ba.sum.fsre.kvizznanja.UserProfile
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class LoginViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = AuthRepository()

    private val _loginState = MutableStateFlow<LoginState>(LoginState.Idle)
    val loginState: StateFlow<LoginState> = _loginState

    fun login(email: String, password: String) {
        _loginState.value = LoginState.Loading
        viewModelScope.launch {
            val result = repo.login(email, password)
            result.onSuccess { user ->
                spremiProfilURoom(user)
                _loginState.value = LoginState.Success(user)
            }.onFailure { e ->
                _loginState.value = LoginState.Error(e.message ?: "Greška pri prijavi")
            }
        }
    }

    fun currentUser() = repo.currentUser()

    private suspend fun spremiProfilURoom(user: FirebaseUserData) {
        try {
            val dao = AppDatabase.getInstance(getApplication()).userProfileDao()
            val doc = FirebaseFirestore.getInstance()
                .collection("korisnici")
                .document(user.uid)
                .get()
                .await()

            dao.insertOrReplace(
                UserProfile(
                    uid              = user.uid,
                    fullName         = doc.getString("ime") ?: "",
                    email            = doc.getString("email") ?: "",
                    ukupnoKvizova    = (doc.getLong("ukupno_kvizova") ?: 0).toInt(),
                    najboljiRezultat = (doc.getLong("najbolji_rezultat") ?: 0).toInt(),
                    ukupniBodovi     = (doc.getLong("ukupni_bodovi") ?: 0).toInt(),
                    lastLoginAt      = System.currentTimeMillis()
                )
            )
        } catch (_: Exception) { /* nema interneta — nije kritično */ }
    }
}

sealed class LoginState {
    object Idle    : LoginState()
    object Loading : LoginState()
    data class Success(val user: FirebaseUserData) : LoginState()
    data class Error(val message: String)          : LoginState()
}

