package ba.sum.fsre.kvizznanja

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "user_profile",
    indices = [Index(value = ["email"], unique = true)]
)
data class UserProfile(
    @PrimaryKey
    val uid: String,
    val fullName: String,
    val email: String,
    val ukupnoKvizova: Int = 0,
    val najboljiRezultat: Int = 0,
    val ukupniBodovi: Int = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val lastLoginAt: Long = System.currentTimeMillis()
)