package ba.sum.fsre.kvizznanja.ui.result

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import ba.sum.fsre.kvizznanja.AuthRepository
import ba.sum.fsre.kvizznanja.R
import ba.sum.fsre.kvizznanja.SessionManager
import ba.sum.fsre.kvizznanja.ui.home.HomeActivity
import ba.sum.fsre.kvizznanja.ui.leaderboard.LeaderboardActivity
import com.google.android.material.button.MaterialButton

class ResultActivity : AppCompatActivity() {

    private val viewModel: ResultViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)
        supportActionBar?.hide()

        val correct = intent.getIntExtra("CORRECT", 0)
        val total   = intent.getIntExtra("TOTAL", 0)
        val score   = intent.getIntExtra("SCORE", 0)

        val repo = AuthRepository()
        val uid  = repo.currentUser()?.uid
            ?: SessionManager(this).getUserUid()

        if (uid != null) {
            viewModel.spremiRezultat(uid, score)
        }

        // Prikaži rezultate
        findViewById<TextView>(R.id.tvTocno).text  = "$correct / $total"
        findViewById<TextView>(R.id.tvBodovi).text = "$score"

        val emoji = when {
            correct >= total * 0.8 -> "🎉"
            correct >= total * 0.5 -> "😊"
            else -> "😅"
        }
        findViewById<TextView>(R.id.tvEmoji).text = emoji

        findViewById<MaterialButton>(R.id.btnLeaderboard).setOnClickListener {
            startActivity(Intent(this, LeaderboardActivity::class.java))
        }

        findViewById<MaterialButton>(R.id.btnBackToHome).setOnClickListener {
            startActivity(Intent(this, HomeActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
            })
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}