package ba.sum.fsre.kvizznanja

import android.content.Context

class SessionManager(context: Context) {
    private val prefs = context.getSharedPreferences("session", Context.MODE_PRIVATE)

    fun saveLogin(userId: Long) {
        prefs.edit()
            .putBoolean("isLoggedIn", true)
            .putLong("userId", userId)
            .apply()
    }

    fun saveLoginWithUid(uid: String) {
        prefs.edit()
            .putBoolean("isLoggedIn", true)
            .putLong("userId", uid.hashCode().toLong())
            .putString("userUid", uid)
            .apply()
    }

    fun isLoggedIn(): Boolean = prefs.getBoolean("isLoggedIn", false)
    fun getUserId(): Long = prefs.getLong("userId", -1)
    fun getUserUid(): String? = prefs.getString("userUid", null)

    fun logout() {
        prefs.edit().clear().apply()
    }
}