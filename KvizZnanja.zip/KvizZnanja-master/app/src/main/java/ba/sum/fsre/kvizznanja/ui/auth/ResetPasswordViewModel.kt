package ba.sum.fsre.kvizznanja.ui.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import ba.sum.fsre.kvizznanja.AuthRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class ResetPasswordViewModel : ViewModel() {

    private val repo = AuthRepository()

    private val _resetState = MutableStateFlow<ResetState>(ResetState.Idle)
    val resetState: StateFlow<ResetState> = _resetState

    fun sendResetEmail(email: String) {
        _resetState.value = ResetState.Loading
        viewModelScope.launch {
            val result = repo.sendPasswordResetEmail(email)
            result.onSuccess {
                _resetState.value = ResetState.Success
            }.onFailure { e ->
                _resetState.value = ResetState.Error(e.message ?: "Greška pri slanju")
            }
        }
    }
}

sealed class ResetState {
    object Idle    : ResetState()
    object Loading : ResetState()
    object Success : ResetState()
    data class Error(val message: String) : ResetState()
}

