package ba.sum.fsre.kvizznanja.ui.profile

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import ba.sum.fsre.kvizznanja.R
import ba.sum.fsre.kvizznanja.SessionManager
import ba.sum.fsre.kvizznanja.UserProfile
import ba.sum.fsre.kvizznanja.ui.auth.LoginActivity
import ba.sum.fsre.kvizznanja.ui.home.HomeActivity
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.launch

class ProfileActivity : AppCompatActivity() {

    private lateinit var session: SessionManager
    private val viewModel: ProfileViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)
        supportActionBar?.hide()

        session = SessionManager(this)

        val tvName         = findViewById<TextView>(R.id.tvName)
        val tvEmail        = findViewById<TextView>(R.id.tvEmail)
        val tvTotalQuizzes = findViewById<TextView>(R.id.tvTotalQuizzes)
        val tvBestScore    = findViewById<TextView>(R.id.tvBestScore)
        val btnLogout      = findViewById<MaterialButton>(R.id.btnLogout)
        val btnBackToHome  = findViewById<MaterialButton>(R.id.btnBackToHome)

        val uid = viewModel.currentUser()?.uid ?: session.getUserUid()

        if (uid != null) {
            viewModel.loadProfile(uid)

            // Promatraj stanje profila iz ViewModela
            lifecycleScope.launch {
                viewModel.profileState.collect { state ->
                    when (state) {
                        is ProfileState.Success -> prikaziProfil(tvName, tvEmail, tvTotalQuizzes, tvBestScore, state.profile)
                        is ProfileState.Loading -> Unit
                        is ProfileState.Error   -> Unit
                    }
                }
            }
        }

        btnLogout.setOnClickListener {
            if (uid != null) viewModel.logout(uid)
            session.logout()
            val intent = Intent(this, LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }

        btnBackToHome.setOnClickListener {
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
        }
    }

    private fun prikaziProfil(
        tvName: TextView,
        tvEmail: TextView,
        tvTotalQuizzes: TextView,
        tvBestScore: TextView,
        profil: UserProfile
    ) {
        tvName.text         = profil.fullName.ifBlank { "—" }
        tvEmail.text        = profil.email.ifBlank { "—" }
        tvTotalQuizzes.text = profil.ukupnoKvizova.toString()
        tvBestScore.text    = profil.najboljiRezultat.toString()
    }
}